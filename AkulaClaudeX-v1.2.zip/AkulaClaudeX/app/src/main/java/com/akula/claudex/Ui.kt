package com.akula.claudex

import android.graphics.Color as AColor
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.delay

enum class Pending { OPTIMIZE, RESET }

@Composable
fun AkulaApp(vm: MainViewModel) {
    AkulaTheme(vm.lang, vm.theme) { p ->
        val activity = LocalContext.current as ComponentActivity
        LaunchedEffect(p.dark) {
            val style = if (p.dark) SystemBarStyle.dark(AColor.TRANSPARENT)
            else SystemBarStyle.light(AColor.TRANSPARENT, AColor.TRANSPARENT)
            activity.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
        }

        var showApps by rememberSaveable { mutableStateOf(false) }
        var pending by rememberSaveable { mutableStateOf<Pending?>(null) }

        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(p.bg))) {
            Box(
                Modifier
                    .size(280.dp)
                    .offset((-90).dp, (-70).dp)
                    .background(Brush.radialGradient(listOf(p.violet.copy(alpha = p.orbV), Color.Transparent)), CircleShape)
            )
            Box(
                Modifier
                    .size(320.dp)
                    .align(Alignment.BottomEnd)
                    .offset(100.dp, 90.dp)
                    .background(Brush.radialGradient(listOf(p.cyan.copy(alpha = p.orbC), Color.Transparent)), CircleShape)
            )

            Home(
                vm,
                onOpenApps = { showApps = true; vm.loadApps() },
                onConfirm = { pending = it }
            )

            if (showApps) AppPicker(vm, onClose = { showApps = false })

            pending?.let { pd ->
                val title: String
                val body: String
                when (pd) {
                    Pending.OPTIMIZE -> {
                        title = tr("Optimize apps?", "ធ្វើឱ្យកម្មវិធីល្អប្រសើរ?")
                        body = tr(
                            "This can take several minutes and uses battery. Keep your phone on the charger.",
                            "នេះអាចចំណាយពេលច្រើននាទី ហើយប្រើថ្ម។ សូមដោតសាកថ្មទូរសព្ទរបស់អ្នក។"
                        )
                    }
                    Pending.RESET -> {
                        title = tr("Reset all tweaks?", "កំណត់ការកែសម្រួលទាំងអស់ឡើងវិញ?")
                        body = tr(
                            "Animations, refresh rate and battery saver go back to default.",
                            "ចលនា អត្រាធ្វើឱ្យអេក្រង់ឡើងវិញ និងមុខងារសន្សំថ្ម នឹងត្រឡប់ទៅលំនាំដើម។"
                        )
                    }
                }
                ConfirmOverlay(
                    title, body,
                    onYes = {
                        when (pd) {
                            Pending.OPTIMIZE -> vm.optimizeApps()
                            Pending.RESET -> vm.resetAll()
                        }
                        pending = null
                    },
                    onNo = { pending = null }
                )
            }

            CreditOverlay(visible = vm.showCredit, onClose = vm::closeCredit, onHideToday = vm::hideCreditToday)
        }
    }
}

@Composable
private fun Home(vm: MainViewModel, onOpenApps: () -> Unit, onConfirm: (Pending) -> Unit) {
    val p = LocalPal.current

    // Live stats refresh every 3 s, but only while the app is on screen (saves battery).
    val owner = LocalContext.current as ComponentActivity
    LaunchedEffect(owner) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                vm.refreshStats()
                delay(3000)
            }
        }
    }

    val ready = vm.status == Status.READY && !vm.busy

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).padding(end = 8.dp)) {
                Text("AkulaClaudeX", color = p.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text(
                    tr("Android Performance & System Tweaking Utility", "ឧបករណ៍បង្កើនល្បឿន និងកែសម្រួលប្រព័ន្ធ Android"),
                    color = p.accent, fontSize = 12.sp
                )
            }
            GlassButton(tr("Credits", "ក្រេឌីត"), onClick = vm::openCredit)
        }
        Text(
            tr(
                "Performance tweaks powered by Shizuku, no root needed.",
                "ការកែសម្រួលដើម្បីបង្កើនល្បឿន ដោយប្រើ Shizuku មិនចាំបាច់ root ទេ។"
            ),
            color = p.soft, fontSize = 13.sp
        )

        // Language + theme
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassChip(
                if (vm.lang == Lang.EN) "🌐 ខ្មែរ" else "🌐 English",
                Modifier.weight(1f), onClick = vm::toggleLang
            )
            GlassChip(
                when (vm.theme) {
                    ThemeMode.AUTO -> "🌓 " + tr("Auto", "ស្វ័យប្រវត្តិ")
                    ThemeMode.DARK -> "🌙 " + tr("Dark", "ងងឹត")
                    ThemeMode.LIGHT -> "☀️ " + tr("Light", "ភ្លឺ")
                },
                Modifier.weight(1f), onClick = vm::cycleTheme
            )
        }

        StatusCard(vm)

        // One-tap boost
        Column(Modifier.fillMaxWidth().glass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(tr("One-tap Boost", "បង្កើនល្បឿនដោយប៉ះតែម្តង"), color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(
                tr(
                    "Faster animations + free RAM + clear caches in one go, then shows before/after numbers.",
                    "ចលនាលឿនជាងមុន + ដោះលែង RAM + សម្អាត cache ក្នុងពេលតែមួយ រួចបង្ហាញលេខមុន/ក្រោយ។"
                ),
                color = p.soft, fontSize = 12.sp
            )
            GlassButton(tr("Boost", "បង្កើនល្បឿន"), Modifier.fillMaxWidth(), enabled = ready, onClick = vm::boost)
        }

        // Result (right under Boost so you always see what happened)
        SectionTitle(tr("Result", "លទ្ធផល"))
        Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
            if (vm.busy) {
                BusyBar(vm.progress, onCancel = vm::cancel)
            } else {
                Text(
                    vm.result ?: tr("Ready. Pick a tweak below.", "ត្រៀមខ្លួនរួចរាល់។ សូមជ្រើសរើសការកែសម្រួលខាងក្រោម។"),
                    color = p.text, fontSize = 13.sp
                )
            }
        }

        // Live device stats (read from the system, not made up)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile(tr("RAM free", "RAM នៅទំនេរ"), vm.ram, Modifier.weight(1f))
            StatTile(tr("Storage free", "ទំហំផ្ទុកនៅទំនេរ"), vm.storage, Modifier.weight(1f))
        }
        StatTile(tr("Battery", "ថ្ម"), vm.battery, Modifier.fillMaxWidth())

        SectionTitle(tr("Smooth UI", "UI រលូន"))
        TweakCard(
            tr("Faster animations (0.5x)", "ចលនាលឿន (0.5x)"),
            tr(
                "Halves window, transition and animator scales so the UI feels quicker.",
                "កាត់បន្ថយល្បឿនចលនាបង្អួច ការផ្លាស់ប្តូរ និង animator ពាក់កណ្តាល ដើម្បីឱ្យ UI មើលទៅលឿនជាងមុន។"
            ),
            tr("Apply", "អនុវត្ត"), ready
        ) { vm.animationsScale("0.5", tr("Faster animations", "ចលនាលឿន")) }
        TweakCard(
            tr("Animations off", "បិទចលនា"),
            tr(
                "Fastest possible feel on weak phones. Screens switch instantly.",
                "មានអារម្មណ៍លឿនបំផុតសម្រាប់ទូរសព្ទខ្សោយ។ អេក្រង់ប្តូរភ្លាមៗ។"
            ),
            tr("Apply", "អនុវត្ត"), ready
        ) { vm.animationsScale("0", tr("Animations off", "បិទចលនា")) }
        TweakCard(
            tr("Restore animations (1x)", "ស្តារចលនា (1x)"),
            tr("Back to the Android default.", "ត្រឡប់ទៅលំនាំដើមរបស់ Android។"),
            tr("Restore", "ស្តារ"), ready
        ) { vm.animationsScale("1", tr("Restore animations", "ស្តារចលនា")) }

        SectionTitle(tr("Memory & storage", "អង្គចងចាំ និងទំហំផ្ទុក"))
        TweakCard(
            tr("Free RAM", "ដោះលែង RAM"),
            tr(
                "Stops cached background processes so more memory is available right now.",
                "បញ្ឈប់ដំណើរការផ្ទៃខាងក្រោយដែលបានទុកក្នុង cache ដើម្បីឱ្យមានអង្គចងចាំច្រើនឡើងភ្លាមៗ។"
            ),
            tr("Clean", "សម្អាត"), ready, vm::freeRam
        )
        TweakCard(
            tr("Clear app caches", "សម្អាត cache កម្មវិធី"),
            tr(
                "Asks Android to trim cached files across all apps.",
                "ស្នើឱ្យ Android សម្អាតឯកសារ cache នៃកម្មវិធីទាំងអស់។"
            ),
            tr("Clear", "លុប"), ready, vm::clearCaches
        )

        SectionTitle(tr("App speed", "ល្បឿនកម្មវិធី"))
        TweakCard(
            tr("Optimize apps", "ធ្វើឱ្យកម្មវិធីល្អប្រសើរ"),
            tr(
                "Recompiles installed apps with the speed-profile ART filter. Can take a few minutes. Best while charging.",
                "Compile កម្មវិធីដែលបានដំឡើងឡើងវិញដោយប្រើ speed-profile ដើម្បីបើកលឿនជាងមុន។ អាចចំណាយពេលពីរបីនាទី។ ល្អបំផុតពេលកំពុងសាកថ្ម។"
            ),
            tr("Optimize", "បង្កើន"), ready
        ) { onConfirm(Pending.OPTIMIZE) }

        SectionTitle(tr("Manage apps", "គ្រប់គ្រងកម្មវិធី"))
        TweakCard(
            tr("Background apps", "កម្មវិធីផ្ទៃខាងក្រោយ"),
            tr(
                "Pick apps to force stop, or block them from running in the background.",
                "ជ្រើសរើសកម្មវិធីដើម្បីបង្ខំឱ្យឈប់ ឬហាមមិនឱ្យដំណើរការនៅផ្ទៃខាងក្រោយ។"
            ),
            tr("Open", "បើក"), ready, onOpenApps
        )

        SectionTitle(tr("Display", "អេក្រង់"))
        Column(Modifier.fillMaxWidth().glass().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(tr("Refresh rate", "អត្រាធ្វើឱ្យអេក្រង់ឡើងវិញ"), color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(
                tr(
                    "Lock the screen refresh rate. Works only if your display supports it. 60 Hz saves battery.",
                    "ចាក់សោអត្រាធ្វើឱ្យអេក្រង់ឡើងវិញ។ ដំណើរការតែនៅពេលអេក្រង់របស់អ្នកគាំទ្រ។ 60 Hz សន្សំថ្ម។"
                ),
                color = p.soft, fontSize = 12.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("60 Hz", Modifier.weight(1f), ready) { vm.setRefreshRate(60) }
                GlassButton("90 Hz", Modifier.weight(1f), ready) { vm.setRefreshRate(90) }
                GlassButton("120 Hz", Modifier.weight(1f), ready) { vm.setRefreshRate(120) }
                GlassButton(tr("Reset", "កំណត់ឡើងវិញ"), Modifier.weight(1f), ready, vm::resetRefreshRate)
            }
        }

        SectionTitle(tr("Battery", "ថ្ម"))
        Column(Modifier.fillMaxWidth().glass().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(tr("Battery saver", "មុខងារសន្សំថ្ម"), color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(
                tr("Turns Android's battery saver on or off.", "បើ ឬបិទមុខងារសន្សំថ្មរបស់ Android។"),
                color = p.soft, fontSize = 12.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton(tr("On", "បើក"), Modifier.weight(1f), ready) { vm.setBatterySaver(true) }
                GlassButton(tr("Off", "បិទ"), Modifier.weight(1f), ready) { vm.setBatterySaver(false) }
            }
        }

        SectionTitle(tr("Safety", "សុវត្ថិភាព"))
        TweakCard(
            tr("Reset all tweaks", "កំណត់ការកែសម្រួលទាំងអស់ឡើងវិញ"),
            tr(
                "Restores animations, refresh rate and battery saver to default.",
                "ស្តារចលនា អត្រាធ្វើឱ្យអេក្រង់ឡើងវិញ និងមុខងារសន្សំថ្ម ទៅលំនាំដើម។"
            ),
            tr("Reset", "កំណត់ឡើងវិញ"), ready
        ) { onConfirm(Pending.RESET) }

        Text(
            tr("Made by Akula Team · keep the credit", "បង្កើតដោយក្រុម Akula · សូមរក្សាក្រេឌីត"),
            color = p.soft.copy(alpha = 0.7f),
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )
    }
}

@Composable
private fun StatusCard(vm: MainViewModel) {
    val p = LocalPal.current
    val info: Triple<String, String, String?> = when (vm.status) {
        Status.READY -> Triple(
            tr("Shizuku connected", "បានភ្ជាប់ Shizuku"),
            tr("All tweaks are unlocked.", "មុខងារទាំងអស់ត្រូវបានបើក។"),
            null
        )
        Status.CONNECTING -> Triple(
            tr("Connecting…", "កំពុងភ្ជាប់…"),
            tr("Talking to Shizuku. Stuck? Tap Retry.", "កំពុងទាក់ទងជាមួយ Shizuku។ បើជាប់ សូមចុចព្យាយាមម្តងទៀត។"),
            tr("Retry", "ព្យាយាមម្តងទៀត")
        )
        Status.NEED_PERMISSION -> Triple(
            tr("Permission needed", "ត្រូវការការអនុញ្ញាត"),
            tr("Allow AkulaClaudeX in Shizuku.", "សូមអនុញ្ញាតឱ្យ AkulaClaudeX នៅក្នុង Shizuku។"),
            tr("Grant", "អនុញ្ញាត")
        )
        Status.NOT_RUNNING -> Triple(
            tr("Shizuku is not running", "Shizuku មិនកំពុងដំណើរការ"),
            tr(
                "Open Shizuku and start it (Wireless debugging or ADB), then come back.",
                "បើក Shizuku ហើយចាប់ផ្តើមវា (Wireless debugging ឬ ADB) រួចត្រឡប់មកវិញ។"
            ),
            tr("Check again", "ពិនិត្យម្តងទៀត")
        )
        Status.NO_SHIZUKU -> Triple(
            tr("Shizuku not installed", "មិនទាន់ដំឡើង Shizuku"),
            tr(
                "Install Shizuku from its official page, start it, then come back.",
                "សូមដំឡើង Shizuku ពីគេហទំព័រផ្លូវការរបស់វា ចាប់ផ្តើមវា រួចត្រឡប់មកវិញ។"
            ),
            tr("Check again", "ពិនិត្យម្តងទៀត")
        )
    }
    val dot = if (vm.status == Status.READY) p.good else p.warn
    Row(Modifier.fillMaxWidth().glass().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).background(dot, CircleShape))
        Box(Modifier.size(10.dp))
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            Text(info.first, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(info.second, color = p.soft, fontSize = 12.sp)
        }
        if (info.third != null) {
            GlassButton(info.third!!) {
                if (vm.status == Status.NEED_PERMISSION) vm.requestPermission() else vm.retry()
            }
        }
    }
}
