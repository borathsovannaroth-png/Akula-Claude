package com.akula.claudex

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Full-screen list of the user's installed apps: force stop, restrict background, or allow background again. */
@Composable
fun AppPicker(vm: MainViewModel, onClose: () -> Unit) {
    val p = LocalPal.current
    BackHandler { onClose() }
    val canAct = vm.status == Status.READY && !vm.busy && vm.selected.isNotEmpty()

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(p.bg))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).padding(end = 8.dp)) {
                Text(tr("Background apps", "កម្មវិធីផ្ទៃខាងក្រោយ"), color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(
                    tr("Apps you installed", "កម្មវិធីដែលអ្នកបានដំឡើង") + " · " +
                        tr("Selected: ${vm.selected.size}", "បានជ្រើស៖ ${vm.selected.size}"),
                    color = p.accent, fontSize = 12.sp
                )
            }
            GlassButton(tr("Close", "បិទ"), onClick = onClose)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassChip(tr("Select all", "ជ្រើសទាំងអស់"), Modifier.weight(1f), onClick = vm::selectAllApps)
            GlassChip(tr("Clear", "ដកការជ្រើសចេញ"), Modifier.weight(1f), onClick = vm::clearSelection)
        }

        Box(Modifier.weight(1f).fillMaxWidth().glass(RoundedCornerShape(20.dp))) {
            when {
                vm.appsLoading -> Text(
                    tr("Loading apps…", "កំពុងផ្ទុកកម្មវិធី…"),
                    color = p.soft, fontSize = 14.sp, modifier = Modifier.align(Alignment.Center)
                )
                vm.apps.isEmpty() -> Text(
                    tr("No user apps found", "រកមិនឃើញកម្មវិធីរបស់អ្នកប្រើទេ"),
                    color = p.soft, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.Center).padding(16.dp)
                )
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(vm.apps, key = { it.pkg }) { app ->
                        val checked = app.pkg in vm.selected
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { vm.toggleApp(app.pkg) }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val shape = RoundedCornerShape(6.dp)
                            Box(
                                Modifier
                                    .size(22.dp)
                                    .clip(shape)
                                    .then(
                                        if (checked) Modifier.background(Brush.horizontalGradient(listOf(p.violet, p.cyan)), shape)
                                        else Modifier.border(1.5.dp, p.soft, shape)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (checked) Text("✓", color = p.btnText, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Text(app.label, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text(app.pkg, color = p.soft, fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }

        if (vm.busy) {
            BusyBar(vm.progress, onCancel = vm::cancel)
        } else {
            vm.result?.lines()?.firstOrNull()?.let { Text(it, color = p.soft, fontSize = 12.sp) }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassButton(tr("Force stop", "បង្ខំឱ្យឈប់"), Modifier.weight(1f), canAct) { vm.appsAction(AppAction.FORCE_STOP) }
            GlassButton(tr("Restrict", "ដាក់កម្រិត"), Modifier.weight(1f), canAct) { vm.appsAction(AppAction.RESTRICT) }
            GlassButton(tr("Allow", "អនុញ្ញាត"), Modifier.weight(1f), canAct) { vm.appsAction(AppAction.ALLOW) }
        }
        Text(
            tr(
                "Force stop = close now. Restrict = block background running until you tap Allow. Restricted apps may delay notifications.",
                "បង្ខំឱ្យឈប់ = បិទភ្លាមៗ។ ដាក់កម្រិត = ហាមដំណើរការនៅផ្ទៃខាងក្រោយ រហូតដល់អ្នកចុចអនុញ្ញាត។ កម្មវិធីដែលបានដាក់កម្រិតអាចពន្យារការជូនដំណឹង។"
            ),
            color = p.soft, fontSize = 11.sp
        )
    }
}
