package com.akula.claudex

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.em

enum class Lang { EN, KM }

enum class ThemeMode { AUTO, DARK, LIGHT }

@Immutable
data class Pal(
    val dark: Boolean,
    val bg: List<Color>,
    val text: Color,
    val soft: Color,
    val accent: Color,
    val violet: Color,
    val cyan: Color,
    val glassTop: Color,
    val glassBottom: Color,
    val edgeA: Color,
    val edgeB: Color,
    val edgeC: Color,
    val btnText: Color,
    val scrim: Color,
    val good: Color,
    val warn: Color,
    val orbV: Float,
    val orbC: Float
)

val DarkPal = Pal(
    dark = true,
    bg = listOf(Color(0xFF070A14), Color(0xFF101733), Color(0xFF0A0F1F)),
    text = Color(0xFFF2F5FF),
    soft = Color(0xFFB7C0DD),
    accent = Color(0xFF00E5FF),
    violet = Color(0xFF6C5CFF),
    cyan = Color(0xFF00E5FF),
    glassTop = Color.White.copy(alpha = 0.20f),
    glassBottom = Color.White.copy(alpha = 0.06f),
    edgeA = Color.White.copy(alpha = 0.60f),
    edgeB = Color.White.copy(alpha = 0.06f),
    edgeC = Color.White.copy(alpha = 0.30f),
    btnText = Color(0xFF05070F),
    scrim = Color(0xAA000000),
    good = Color(0xFF3DFFA2),
    warn = Color(0xFFFFC857),
    orbV = 0.35f,
    orbC = 0.28f
)

val LightPal = Pal(
    dark = false,
    bg = listOf(Color(0xFFF6F8FF), Color(0xFFE4E9FF), Color(0xFFF1F4FF)),
    text = Color(0xFF11162B),
    soft = Color(0xFF47507A),
    accent = Color(0xFF4A3BE0),
    violet = Color(0xFF6C5CFF),
    cyan = Color(0xFF00E5FF),
    glassTop = Color.White.copy(alpha = 0.90f),
    glassBottom = Color.White.copy(alpha = 0.55f),
    edgeA = Color(0xFF6C5CFF).copy(alpha = 0.40f),
    edgeB = Color(0xFF6C5CFF).copy(alpha = 0.08f),
    edgeC = Color(0xFF6C5CFF).copy(alpha = 0.25f),
    btnText = Color(0xFF05070F),
    scrim = Color(0x99000000),
    good = Color(0xFF0E9F6E),
    warn = Color(0xFFB7791F),
    orbV = 0.22f,
    orbC = 0.30f
)

val LocalPal = staticCompositionLocalOf { DarkPal }
val LocalLang = staticCompositionLocalOf { Lang.EN }

/** Picks the English or Khmer text for the language the user chose. */
@Composable
fun tr(en: String, km: String): String = if (LocalLang.current == Lang.KM) km else en

@Composable
fun AkulaTheme(lang: Lang, mode: ThemeMode, content: @Composable (Pal) -> Unit) {
    val dark = when (mode) {
        ThemeMode.AUTO -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val pal = if (dark) DarkPal else LightPal
    // Khmer script has tall stacked marks; extra line height keeps it from being clipped.
    val base = LocalTextStyle.current
    val style = if (lang == Lang.KM) base.merge(TextStyle(lineHeight = 1.6.em)) else base
    CompositionLocalProvider(
        LocalPal provides pal,
        LocalLang provides lang,
        LocalTextStyle provides style
    ) {
        content(pal)
    }
}
