# AkulaClaudeX

Free performance tweaks for low-end Android phones, powered by Shizuku. No root needed.
Made by Akula Team (Borath Sovannroth + Claude). Please keep the credit.

Languages: English and ខ្មែរ (Khmer). Themes: Auto / Dark / Light. Settings are saved.

## Build
1. Open this folder in Android Studio (Ladybug or newer). It syncs Gradle and downloads dependencies.
2. Run on a device, or Build > Build APK(s). (Release APK is debug-signed so it installs; use your own keystore before publishing to a store.)
3. Command line: run `gradle wrapper --gradle-version 8.9` once to create `gradlew`.

## GitHub (automatic APK + web page)
1. Create a repo, upload this whole folder (keep `.github/`), push to `main`.
2. **APK:** open the Actions tab, run "Build APK" (it runs on every push). When it finishes, download `AkulaClaudeX-apk` from the run page.
   To publish a download for everyone: create a tag, e.g. `git tag v1.1 && git push origin v1.1`. The APK is attached to a Release.
3. **Web version:** Settings > Pages > Source: **GitHub Actions**. The page in `docs/index.html` goes live at `https://<you>.github.io/<repo>/`.

## Use
1. Install Shizuku and start it (Wireless debugging on Android 11+, or ADB).
2. Open AkulaClaudeX, tap Grant in the status card.
3. Tap Boost, or pick any tweak. The Result box shows real output and before/after numbers.

## Features
| Feature | Command(s) | Effect |
|---|---|---|
| One-tap Boost | animations 0.5x + `am kill-all` + `pm trim-caches` | Everything quick, with before/after RAM and storage |
| Faster animations / off / restore | `settings put global *_scale` | UI feels quicker; values are read back to verify |
| Free RAM | `am kill-all` | Stops cached background processes |
| Clear app caches | `pm trim-caches` | Frees cached storage |
| Optimize apps | `cmd package compile -m speed-profile -a` | Faster app launches (slow, confirm dialog, run on charger) |
| Refresh rate | `settings put system peak/min_refresh_rate` | Lock 60/90/120 Hz (only if the display supports it) |
| Battery saver | `settings put global low_power` | On / off |
| Background apps | `am force-stop`, `cmd appops set ... RUN_IN_BACKGROUND` | Pick apps to stop now, or block background running (reversible with Allow) |
| Reset all tweaks | restores defaults | Animations, refresh rate, battery saver |
| Cancel button | | Stops a running command |

No fake boosters. RAM/cache cleaning is temporary because Android refills them; animation scale gives the biggest "smoother" feeling.

## Safety
`ShellService` does not run free shell text. Each command is split into arguments, matched against a strict allow-list
(fixed settings keys, package-name checks) and started without a shell, with a timeout.
To add a new tweak, add its command to `allowed()` in `ShellService.kt` and a function in `MainViewModel.kt`.

## Where things are
- `Theme.kt`: light/dark colors, language switch (`tr("English", "ខ្មែរ")`)
- `Ui.kt`: home screen. `AppPicker.kt`: background apps list. `Components.kt`: buttons, glass cards, credit popup
- Credit popup: shown on launch (can be hidden for today), "Credits" button reopens it
