package com.akula.claudex

import android.app.ActivityManager
import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Environment
import android.os.IBinder
import android.os.StatFs
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class Status { NO_SHIZUKU, NOT_RUNNING, NEED_PERMISSION, CONNECTING, READY }

class MainViewModel(app: Application) : AndroidViewModel(app) {

    var status by mutableStateOf(Status.CONNECTING)
        private set
    var busy by mutableStateOf(false)
        private set
    var log by mutableStateOf("Ready. Pick a tweak below.")
        private set
    var ram by mutableStateOf("--")
        private set
    var storage by mutableStateOf("--")
        private set
    var battery by mutableStateOf("--")
        private set

    private var service: IShellService? = null

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = if (binder != null && binder.pingBinder()) IShellService.Stub.asInterface(binder) else null
            status = if (service != null) Status.READY else Status.CONNECTING
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            refresh()
        }
    }

    private val binderReceived = Shizuku.OnBinderReceivedListener { refresh() }
    private val binderDead = Shizuku.OnBinderDeadListener {
        service = null
        refresh()
    }
    private val permissionResult = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    init {
        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permissionResult)
        refreshStats()
    }

    override fun onCleared() {
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permissionResult)
        super.onCleared()
    }

    private fun shizukuInstalled(): Boolean = try {
        getApplication<Application>().packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
        true
    } catch (_: Exception) {
        false
    }

    /** Re-checks Shizuku state and connects the shell service when everything is ready. */
    fun refresh() {
        refreshStats()
        if (!Shizuku.pingBinder()) {
            service = null
            status = if (shizukuInstalled()) Status.NOT_RUNNING else Status.NO_SHIZUKU
            return
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            status = Status.NEED_PERMISSION
            return
        }
        if (service != null) {
            status = Status.READY
            return
        }
        status = Status.CONNECTING
        val ctx = getApplication<Application>()
        val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, ShellService::class.java.name))
            .processNameSuffix("shell")
            .daemon(false)
            .version(1)
        try {
            Shizuku.bindUserService(args, connection)
        } catch (e: Exception) {
            log = "Could not connect: ${e.message}"
        }
    }

    fun requestPermission() {
        if (Shizuku.pingBinder()) Shizuku.requestPermission(100)
    }

    fun refreshStats() {
        val ctx = getApplication<Application>()
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        ram = "${mi.availMem.toMb()} / ${mi.totalMem.toMb()} MB"

        val sf = StatFs(Environment.getDataDirectory().path)
        storage = "${(sf.availableBytes / 1_073_741_824.0).fmt()} / ${(sf.totalBytes / 1_073_741_824.0).fmt()} GB"

        val bi = ctx.registerReceiver(null, IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
        val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        battery = if (level >= 0) "${level * 100 / scale}% · ${temp.fmt()}°C" else "--"
    }

    private fun Long.toMb() = this / 1_048_576
    private fun Double.fmt() = String.format("%.1f", this)

    // ---- Tweaks (each one runs real shell commands through Shizuku) ----

    fun animationsScale(scale: String, label: String) = runTweak(
        label,
        "settings put global window_animation_scale $scale",
        "settings put global transition_animation_scale $scale",
        "settings put global animator_duration_scale $scale",
        "echo window=\$(settings get global window_animation_scale) " +
            "transition=\$(settings get global transition_animation_scale) " +
            "animator=\$(settings get global animator_duration_scale)"
    )

    fun freeRam() = runTweak("Free RAM", "am kill-all", "echo Background processes stopped.")

    fun clearCaches() = runTweak("Clear app caches", "pm trim-caches 999999999999", "echo Cache trim requested.")

    fun optimizeApps() = runTweak(
        "Optimize apps (speed-profile)",
        "cmd package compile -m speed-profile -a"
    )

    private fun runTweak(title: String, vararg commands: String) {
        val s = service ?: run { log = "Shizuku is not ready yet."; return }
        if (busy) return
        busy = true
        log = "$title…"
        viewModelScope.launch(Dispatchers.IO) {
            val out = StringBuilder()
            try {
                commands.forEach { out.appendLine(s.exec(it).ifBlank { "ok" }) }
            } catch (e: Exception) {
                out.append("failed: ${e.message}")
            }
            withContext(Dispatchers.Main) {
                log = "$title – done\n${out.toString().trim().take(600)}"
                busy = false
                refreshStats()
            }
        }
    }
}
