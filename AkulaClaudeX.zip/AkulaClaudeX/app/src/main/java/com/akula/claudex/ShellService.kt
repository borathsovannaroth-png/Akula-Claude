package com.akula.claudex

import kotlin.system.exitProcess

/**
 * Runs inside the Shizuku-started process (shell privileges, no root).
 * The app only ever sends the fixed commands defined in MainViewModel.
 */
class ShellService : IShellService.Stub() {

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(command: String): String {
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val output = process.inputStream.bufferedReader().readText()
            process.waitFor()
            output.trim()
        } catch (e: Exception) {
            "error: ${e.message}"
        }
    }
}
