package com.akula.claudex

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Cyan = Color(0xFF00E5FF)
private val Violet = Color(0xFF6C5CFF)
private val TextMain = Color(0xFFF2F5FF)
private val TextSoft = Color(0xFFB7C0DD)

/** Cheap "liquid glass" look: translucent gradient fill + bright edge highlight. No blur, so it stays smooth on low-end GPUs. */
fun Modifier.glass(shape: Shape = RoundedCornerShape(22.dp)): Modifier = this
    .clip(shape)
    .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.20f), Color.White.copy(alpha = 0.06f))))
    .border(
        1.dp,
        Brush.linearGradient(listOf(Color.White.copy(alpha = 0.60f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.30f))),
        shape
    )

@Composable
fun AkulaApp(vm: MainViewModel) {
    var showCredit by rememberSaveable { mutableStateOf(true) } // pops up every time the app opens

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF070A14), Color(0xFF101733), Color(0xFF0A0F1F))))
    ) {
        Box(
            Modifier
                .size(280.dp)
                .offset((-90).dp, (-70).dp)
                .background(Brush.radialGradient(listOf(Violet.copy(alpha = 0.35f), Color.Transparent)), CircleShape)
        )
        Box(
            Modifier
                .size(320.dp)
                .align(Alignment.BottomEnd)
                .offset(100.dp, 90.dp)
                .background(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.28f), Color.Transparent)), CircleShape)
        )

        Home(vm, onCredits = { showCredit = true })
        CreditOverlay(visible = showCredit, onClose = { showCredit = false })
    }
}

@Composable
private fun Home(vm: MainViewModel, onCredits: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("AkulaClaudeX", color = TextMain, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Android Performance & System Tweaking Utility", color = Cyan, fontSize = 12.sp)
            }
            GlassButton("Credits", onClick = onCredits)
        }
        Text("Performance tweaks powered by Shizuku, no root needed.", color = TextSoft, fontSize = 13.sp)

        StatusCard(vm)

        // Live device stats (read from the system, not made up)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("RAM free", vm.ram, Modifier.weight(1f))
            StatTile("Storage free", vm.storage, Modifier.weight(1f))
        }
        StatTile("Battery", vm.battery, Modifier.fillMaxWidth())

        val ready = vm.status == Status.READY && !vm.busy

        SectionTitle("Smooth UI")
        TweakCard("Faster animations (0.5x)", "Halves window, transition and animator scales so the UI feels quicker.", "Apply", ready) {
            vm.animationsScale("0.5", "Faster animations")
        }
        TweakCard("Animations off", "Fastest possible feel on weak phones. Screens switch instantly.", "Apply", ready) {
            vm.animationsScale("0", "Animations off")
        }
        TweakCard("Restore animations (1x)", "Back to the Android default.", "Restore", ready) {
            vm.animationsScale("1", "Restore animations")
        }

        SectionTitle("Memory & storage")
        TweakCard("Free RAM", "Stops cached background processes so more memory is available right now.", "Clean", ready) {
            vm.freeRam()
        }
        TweakCard("Clear app caches", "Asks Android to trim cached files across all apps.", "Clear", ready) {
            vm.clearCaches()
        }

        SectionTitle("App speed")
        TweakCard("Optimize apps", "Recompiles installed apps with the speed-profile ART filter. Can take a few minutes.", "Optimize", ready) {
            vm.optimizeApps()
        }

        SectionTitle("Result")
        Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
            Text(if (vm.busy) "Working…" else vm.log, color = TextMain, fontSize = 13.sp)
        }

        Text(
            "Made by Akula Team · keep the credit",
            color = TextSoft.copy(alpha = 0.7f),
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )
    }
}

@Composable
private fun StatusCard(vm: MainViewModel) {
    val (title, body, action) = when (vm.status) {
        Status.READY -> Triple("Shizuku connected", "All tweaks are unlocked.", null)
        Status.CONNECTING -> Triple("Connecting…", "Talking to Shizuku.", null)
        Status.NEED_PERMISSION -> Triple("Permission needed", "Allow AkulaClaudeX in Shizuku.", "Grant")
        Status.NOT_RUNNING -> Triple("Shizuku is not running", "Open Shizuku and start it (Wireless debugging or ADB), then come back.", "Check again")
        Status.NO_SHIZUKU -> Triple("Shizuku not installed", "Install Shizuku from its official page, start it, then come back.", "Check again")
    }
    val dot = if (vm.status == Status.READY) Color(0xFF3DFFA2) else Color(0xFFFFC857)
    Row(
        Modifier.fillMaxWidth().glass().padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(10.dp).background(dot, CircleShape))
        Spacer(Modifier.size(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(body, color = TextSoft, fontSize = 12.sp)
        }
        if (action != null) {
            GlassButton(action) {
                if (vm.status == Status.NEED_PERMISSION) vm.requestPermission() else vm.refresh()
            }
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier) {
    Column(modifier.glass().padding(12.dp)) {
        Text(label, color = TextSoft, fontSize = 11.sp)
        Text(value, color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun TweakCard(title: String, desc: String, button: String, enabled: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().glass().padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Text(title, color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(desc, color = TextSoft, fontSize = 12.sp)
        }
        GlassButton(button, enabled = enabled, onClick = onClick)
    }
}

@Composable
private fun GlassButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Violet, Cyan)), shape)
            .then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) Color(0xFF05070F) else Color(0x8805070F), fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

/** The credit "watermark board": liquid-glass card that pops up on launch, with a wide slim X bar at the bottom to close it. */
@Composable
private fun CreditOverlay(visible: Boolean, onClose: () -> Unit) {
    val uri = LocalUriHandler.current
    BackHandler(enabled = visible) { onClose() }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(220)) + slideInVertically(tween(320)) { it / 3 },
        exit = fadeOut(tween(180)) + slideOutVertically(tween(240)) { it / 3 }
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0xAA000000))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
            contentAlignment = Alignment.BottomCenter
        ) {
            Column(
                Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(28.dp))
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Please add credit to us bro, let's gooo! 🔥", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Hi Maaa Boyy 👋", color = Cyan, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        "We are Akula Team, from Borath Sovannroth and Claude, also known as ma big broo.",
                        color = TextMain, fontSize = 14.sp
                    )
                    Text(
                        "Please keep the rights with us. No stealing or copying allowed.",
                        color = TextSoft, fontSize = 13.sp
                    )
                    Text("Media", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    LinkChip("Telegram · t.me/Rachana_lover21") { uri.openUri("https://t.me/Rachana_lover21") }
                    LinkChip("TikTok · @only_florian_naz") { uri.openUri("https://www.tiktok.com/@only_florian_naz") }
                }

                // Wide + slim X bar to dismiss
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(38.dp)
                        .glass(RoundedCornerShape(19.dp))
                        .clickable(onClick = onClose),
                    contentAlignment = Alignment.Center
                ) {
                    Text("✕", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun LinkChip(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color.White.copy(alpha = 0.10f))
            .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Text(text, color = TextMain, fontSize = 13.sp)
    }
}
