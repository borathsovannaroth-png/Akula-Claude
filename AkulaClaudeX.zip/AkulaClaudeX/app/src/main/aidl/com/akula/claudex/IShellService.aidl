package com.akula.claudex;

interface IShellService {
    // Transaction id required by Shizuku for the destroy call.
    void destroy() = 16777114;

    // Runs a shell command with Shizuku's (shell) privileges and returns its output.
    String exec(String command) = 1;
}
