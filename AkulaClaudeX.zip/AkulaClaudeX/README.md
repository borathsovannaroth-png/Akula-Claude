# AkulaClaudeX

Performance tweaks powered by Shizuku, no root needed.
Made by Akula Team (Borath Sovannroth + Claude). Please keep the credit.

## Build
1. Open this folder in Android Studio (Ladybug or newer). It creates the Gradle wrapper and downloads dependencies.
2. Run on a device, or Build > Build APK(s).

## Use
1. Install Shizuku and start it (Wireless debugging on Android 11+, or ADB).
2. Open AkulaClaudeX, tap Grant in the status card.
3. Pick a tweak. The Result box shows the real command output.

## What each tweak really does
| Tweak | Command(s) | Effect |
|---|---|---|
| Faster animations / off / restore | `settings put global window_animation_scale`, `transition_animation_scale`, `animator_duration_scale` | UI feels quicker; verified by reading the values back |
| Free RAM | `am kill-all` | Stops cached background processes |
| Clear app caches | `pm trim-caches` | Frees cached storage |
| Optimize apps | `cmd package compile -m speed-profile -a` | Recompiles apps for faster launches (slow, run on charger) |

No fake boosters. Gains are real but modest: animation scale gives the biggest "smoother" feeling on weak phones; RAM/cache cleaning is temporary because Android refills them.

## Credit popup
`Ui.kt > CreditOverlay`: liquid-glass board shown on every launch, wide slim X bar at the bottom closes it, "Credits" button reopens it. Edit the text/links there.
